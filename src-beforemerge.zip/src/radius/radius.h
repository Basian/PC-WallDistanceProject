/*
 * radius.h
 *
 *  Created on: Nov 7, 2014
 *      Author: nathan
 */

#ifndef RADIUS_H_
#define RADIUS_H_


void radius(int size, double * xc, double * yc, double * r);


#endif /* RADIUS_H_ */
