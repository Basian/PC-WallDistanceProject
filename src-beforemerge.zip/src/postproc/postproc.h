/*
 * postproc.h
 *
 *  Created on: Nov 6, 2014
 *      Author: nathan
 */

#ifndef POSTPROC_H_
#define POSTPROC_H_

void postproc(int,int,double *);



#endif /* POSTPROC_H_ */
