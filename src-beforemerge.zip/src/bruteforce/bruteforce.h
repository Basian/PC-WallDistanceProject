/*
 * bruteforce.h
 *
 *  Created on: Nov 11, 2014
 *      Author: vasanth
 */

#ifndef BRUTEFORCE_H_
#define BRUTEFORCE_H_


void SerialBF(int csize, int fsize, double * xc, double * yc, double * xf, double * yf, double * wallDist);


#endif /* BRUTEFORCE_H_ */
