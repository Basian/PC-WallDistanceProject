/*
 * preproc.h
 *
 *  Created on: Nov 1, 2014
 *      Author: nathan
 */

#ifndef PREPROC_H_
#define PREPROC_H_

void preproc(int &,int &, double *&, double *&, double *&, double *&);



#endif /* PREPROC_H_ */
